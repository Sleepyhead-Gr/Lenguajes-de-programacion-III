﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2
{
    partial class frmInfoPersonal
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabDatos = new System.Windows.Forms.TabPage();
            this.tabClinicos = new System.Windows.Forms.TabPage();
            this.btnRegresar = new System.Windows.Forms.Button();

            // ── Tab1: Datos Personales ──
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.lblCiudad = new System.Windows.Forms.Label();
            this.txtCiudad = new System.Windows.Forms.TextBox();
            this.lblFecha = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.lblEstadoCivil = new System.Windows.Forms.Label();
            this.cmbEstadoCivil = new System.Windows.Forms.ComboBox();
            this.lblSexo = new System.Windows.Forms.Label();
            this.rbHombre = new System.Windows.Forms.RadioButton();
            this.rbMujer = new System.Windows.Forms.RadioButton();
            this.panelImagen = new System.Windows.Forms.Panel();
            this.lblImagenDeco = new System.Windows.Forms.Label();

            // ── Tab2: Datos Clínicos ──
            this.lblPregunta1 = new System.Windows.Forms.Label();
            this.rbEnfSi = new System.Windows.Forms.RadioButton();
            this.rbEnfNo = new System.Windows.Forms.RadioButton();
            this.cmbEnfermedades = new System.Windows.Forms.ComboBox();
            this.lblPregunta2 = new System.Windows.Forms.Label();
            this.rbAlerSi = new System.Windows.Forms.RadioButton();
            this.rbAlerNo = new System.Windows.Forms.RadioButton();
            this.cmbAlergias = new System.Windows.Forms.ComboBox();
            this.lblPregunta3 = new System.Windows.Forms.Label();
            this.rbOpSi = new System.Windows.Forms.RadioButton();
            this.rbOpNo = new System.Windows.Forms.RadioButton();
            this.cmbOperaciones = new System.Windows.Forms.ComboBox();
            this.lblPregunta4 = new System.Windows.Forms.Label();
            this.rbEjSi = new System.Windows.Forms.RadioButton();
            this.rbEjNo = new System.Windows.Forms.RadioButton();
            this.cmbEjercicio = new System.Windows.Forms.ComboBox();
            this.lblPregunta5 = new System.Windows.Forms.Label();
            this.rbDepSi = new System.Windows.Forms.RadioButton();
            this.rbDepNo = new System.Windows.Forms.RadioButton();

            this.panelHeader.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabDatos.SuspendLayout();
            this.tabClinicos.SuspendLayout();
            this.panelImagen.SuspendLayout();
            this.SuspendLayout();

            // ── panelHeader ──
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.panelHeader.Controls.Add(this.lblTitulo);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(680, 60);

            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Text = "INFORMACIÓN PERSONAL";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── tabControl ──
            this.tabControl.Controls.Add(this.tabDatos);
            this.tabControl.Controls.Add(this.tabClinicos);
            this.tabControl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.tabControl.Location = new System.Drawing.Point(15, 70);
            this.tabControl.Name = "tabControl";
            this.tabControl.Size = new System.Drawing.Size(648, 460);
            this.tabControl.TabIndex = 1;

            // ════════════════════════════════════════
            // TAB 1 – Datos Personales
            // ════════════════════════════════════════
            this.tabDatos.BackColor = System.Drawing.Color.White;
            this.tabDatos.Name = "tabDatos";
            this.tabDatos.Text = "Datos Personales";
            this.tabDatos.Padding = new System.Windows.Forms.Padding(5);

            System.Drawing.Font fBold = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            System.Drawing.Font fNormal = new System.Drawing.Font("Segoe UI", 10F);
            System.Drawing.Color azul = System.Drawing.Color.FromArgb(30, 30, 60);

            int x1 = 20, x2 = 215, w = 195, gap = 45;

            // Nombre
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = fBold; this.lblNombre.ForeColor = azul;
            this.lblNombre.Location = new System.Drawing.Point(x1, 20); this.lblNombre.Text = "Nombre:";
            this.txtNombre.Font = fNormal; this.txtNombre.Size = new System.Drawing.Size(w, 27);
            this.txtNombre.Location = new System.Drawing.Point(x2, 18);

            // Apellido
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = fBold; this.lblApellido.ForeColor = azul;
            this.lblApellido.Location = new System.Drawing.Point(x1, 20 + gap); this.lblApellido.Text = "Apellido:";
            this.txtApellido.Font = fNormal; this.txtApellido.Size = new System.Drawing.Size(w, 27);
            this.txtApellido.Location = new System.Drawing.Point(x2, 18 + gap);

            // Dirección
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Font = fBold; this.lblDireccion.ForeColor = azul;
            this.lblDireccion.Location = new System.Drawing.Point(x1, 20 + gap * 2); this.lblDireccion.Text = "Dirección:";
            this.txtDireccion.Font = fNormal; this.txtDireccion.Size = new System.Drawing.Size(w, 27);
            this.txtDireccion.Location = new System.Drawing.Point(x2, 18 + gap * 2);

            // Ciudad
            this.lblCiudad.AutoSize = true;
            this.lblCiudad.Font = fBold; this.lblCiudad.ForeColor = azul;
            this.lblCiudad.Location = new System.Drawing.Point(x1, 20 + gap * 3); this.lblCiudad.Text = "Ciudad:";
            this.txtCiudad.Font = fNormal; this.txtCiudad.Size = new System.Drawing.Size(w, 27);
            this.txtCiudad.Location = new System.Drawing.Point(x2, 18 + gap * 3);

            // Fecha de Nacimiento
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = fBold; this.lblFecha.ForeColor = azul;
            this.lblFecha.Location = new System.Drawing.Point(x1, 20 + gap * 4); this.lblFecha.Text = "Fecha de Nacimiento:";
            this.dtpFecha.Font = fNormal; this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Size = new System.Drawing.Size(w, 27); this.dtpFecha.Location = new System.Drawing.Point(x2, 18 + gap * 4);

            // Estado Civil
            this.lblEstadoCivil.AutoSize = true;
            this.lblEstadoCivil.Font = fBold; this.lblEstadoCivil.ForeColor = azul;
            this.lblEstadoCivil.Location = new System.Drawing.Point(x1, 20 + gap * 5); this.lblEstadoCivil.Text = "Estado Civil:";
            this.cmbEstadoCivil.Font = fNormal; this.cmbEstadoCivil.Size = new System.Drawing.Size(w, 27);
            this.cmbEstadoCivil.Location = new System.Drawing.Point(x2, 18 + gap * 5);
            this.cmbEstadoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstadoCivil.Items.AddRange(new object[] { "Soltero/a", "Casado/a", "Divorciado/a", "Viudo/a" });

            // Sexo
            this.lblSexo.AutoSize = true;
            this.lblSexo.Font = fBold; this.lblSexo.ForeColor = azul;
            this.lblSexo.Location = new System.Drawing.Point(x1, 20 + gap * 6); this.lblSexo.Text = "Sexo:";
            this.rbHombre.Font = fNormal; this.rbHombre.Text = "Hombre";
            this.rbHombre.Location = new System.Drawing.Point(x2, 18 + gap * 6); this.rbHombre.AutoSize = true;
            this.rbMujer.Font = fNormal; this.rbMujer.Text = "Mujer";
            this.rbMujer.Location = new System.Drawing.Point(x2 + 105, 18 + gap * 6); this.rbMujer.AutoSize = true;

            // Panel imagen decorativa
            this.panelImagen.BackColor = System.Drawing.Color.FromArgb(230, 235, 255);
            this.panelImagen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelImagen.Location = new System.Drawing.Point(445, 15);
            this.panelImagen.Size = new System.Drawing.Size(165, 250);
            this.panelImagen.Controls.Add(this.lblImagenDeco);
            this.lblImagenDeco.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblImagenDeco.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblImagenDeco.ForeColor = azul;
            this.lblImagenDeco.Text = "👤\nDatos\nPersonales";
            this.lblImagenDeco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.tabDatos.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblNombre, txtNombre, lblApellido, txtApellido,
                lblDireccion, txtDireccion, lblCiudad, txtCiudad,
                lblFecha, dtpFecha, lblEstadoCivil, cmbEstadoCivil,
                lblSexo, rbHombre, rbMujer, panelImagen });

            // ════════════════════════════════════════
            // TAB 2 – Datos Clínicos
            // ════════════════════════════════════════
            this.tabClinicos.BackColor = System.Drawing.Color.White;
            this.tabClinicos.Name = "tabClinicos";
            this.tabClinicos.Text = "Datos Clínicos";

            int yC = 15, gapC = 72;

            // P1 – Enfermedad
            this.lblPregunta1.AutoSize = true; this.lblPregunta1.Font = fBold; this.lblPregunta1.ForeColor = azul;
            this.lblPregunta1.Location = new System.Drawing.Point(15, yC); this.lblPregunta1.Text = "¿Padeces de alguna enfermedad?";
            this.rbEnfSi.Font = fNormal; this.rbEnfSi.Text = "Sí"; this.rbEnfSi.Location = new System.Drawing.Point(20, yC + 28); this.rbEnfSi.AutoSize = true;
            this.rbEnfNo.Font = fNormal; this.rbEnfNo.Text = "No"; this.rbEnfNo.Location = new System.Drawing.Point(75, yC + 28); this.rbEnfNo.AutoSize = true;
            this.cmbEnfermedades.Font = fNormal; this.cmbEnfermedades.Size = new System.Drawing.Size(195, 25);
            this.cmbEnfermedades.Location = new System.Drawing.Point(150, yC + 26); this.cmbEnfermedades.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnfermedades.Items.AddRange(new object[] { "Diabetes", "Hipertensión", "Asma", "Artritis", "Ninguna" });

            // P2 – Alergias
            this.lblPregunta2.AutoSize = true; this.lblPregunta2.Font = fBold; this.lblPregunta2.ForeColor = azul;
            this.lblPregunta2.Location = new System.Drawing.Point(15, yC + gapC); this.lblPregunta2.Text = "¿Tienes alergias?";
            this.rbAlerSi.Font = fNormal; this.rbAlerSi.Text = "Sí"; this.rbAlerSi.Location = new System.Drawing.Point(20, yC + gapC + 28); this.rbAlerSi.AutoSize = true;
            this.rbAlerNo.Font = fNormal; this.rbAlerNo.Text = "No"; this.rbAlerNo.Location = new System.Drawing.Point(75, yC + gapC + 28); this.rbAlerNo.AutoSize = true;
            this.cmbAlergias.Font = fNormal; this.cmbAlergias.Size = new System.Drawing.Size(195, 25);
            this.cmbAlergias.Location = new System.Drawing.Point(150, yC + gapC + 26); this.cmbAlergias.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAlergias.Items.AddRange(new object[] { "Polen", "Medicamentos", "Alimentos", "Polvo", "Ninguna" });

            // P3 – Operaciones
            this.lblPregunta3.AutoSize = true; this.lblPregunta3.Font = fBold; this.lblPregunta3.ForeColor = azul;
            this.lblPregunta3.Location = new System.Drawing.Point(15, yC + gapC * 2); this.lblPregunta3.Text = "¿Alguna vez te han operado?";
            this.rbOpSi.Font = fNormal; this.rbOpSi.Text = "Sí"; this.rbOpSi.Location = new System.Drawing.Point(20, yC + gapC * 2 + 28); this.rbOpSi.AutoSize = true;
            this.rbOpNo.Font = fNormal; this.rbOpNo.Text = "No"; this.rbOpNo.Location = new System.Drawing.Point(75, yC + gapC * 2 + 28); this.rbOpNo.AutoSize = true;
            this.cmbOperaciones.Font = fNormal; this.cmbOperaciones.Size = new System.Drawing.Size(195, 25);
            this.cmbOperaciones.Location = new System.Drawing.Point(150, yC + gapC * 2 + 26); this.cmbOperaciones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOperaciones.Items.AddRange(new object[] { "Apéndice", "Vesícula", "Corazón", "Rodilla", "Otra" });

            // P4 – Ejercicio
            this.lblPregunta4.AutoSize = true; this.lblPregunta4.Font = fBold; this.lblPregunta4.ForeColor = azul;
            this.lblPregunta4.Location = new System.Drawing.Point(15, yC + gapC * 3); this.lblPregunta4.Text = "¿Haces ejercicio?";
            this.rbEjSi.Font = fNormal; this.rbEjSi.Text = "Sí"; this.rbEjSi.Location = new System.Drawing.Point(20, yC + gapC * 3 + 28); this.rbEjSi.AutoSize = true;
            this.rbEjNo.Font = fNormal; this.rbEjNo.Text = "No"; this.rbEjNo.Location = new System.Drawing.Point(75, yC + gapC * 3 + 28); this.rbEjNo.AutoSize = true;
            this.cmbEjercicio.Font = fNormal; this.cmbEjercicio.Size = new System.Drawing.Size(195, 25);
            this.cmbEjercicio.Location = new System.Drawing.Point(150, yC + gapC * 3 + 26); this.cmbEjercicio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEjercicio.Items.AddRange(new object[] { "Diario", "3 veces/semana", "Fines de semana", "Raramente" });

            // P5 – Depresión (sin combobox)
            this.lblPregunta5.AutoSize = true; this.lblPregunta5.Font = fBold; this.lblPregunta5.ForeColor = azul;
            this.lblPregunta5.Location = new System.Drawing.Point(15, yC + gapC * 4); this.lblPregunta5.Text = "¿Padeces de depresión?";
            this.rbDepSi.Font = fNormal; this.rbDepSi.Text = "Sí"; this.rbDepSi.Location = new System.Drawing.Point(20, yC + gapC * 4 + 28); this.rbDepSi.AutoSize = true;
            this.rbDepNo.Font = fNormal; this.rbDepNo.Text = "No"; this.rbDepNo.Location = new System.Drawing.Point(75, yC + gapC * 4 + 28); this.rbDepNo.AutoSize = true;

            this.tabClinicos.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblPregunta1, rbEnfSi, rbEnfNo, cmbEnfermedades,
                lblPregunta2, rbAlerSi, rbAlerNo, cmbAlergias,
                lblPregunta3, rbOpSi, rbOpNo, cmbOperaciones,
                lblPregunta4, rbEjSi, rbEjNo, cmbEjercicio,
                lblPregunta5, rbDepSi, rbDepNo });

            // ── btnRegresar ──
            this.btnRegresar.BackColor = System.Drawing.Color.FromArgb(183, 28, 28);
            this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(245, 545);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(180, 38);
            this.btnRegresar.TabIndex = 2;
            this.btnRegresar.Text = "Regresar al Menú";
            this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);

            // ── frmInfoPersonal ──
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(680, 600);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.btnRegresar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmInfoPersonal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Información Personal";

            this.panelHeader.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabDatos.ResumeLayout(false);
            this.tabDatos.PerformLayout();
            this.tabClinicos.ResumeLayout(false);
            this.tabClinicos.PerformLayout();
            this.panelImagen.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        // Controles
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabDatos;
        private System.Windows.Forms.TabPage tabClinicos;
        private System.Windows.Forms.Button btnRegresar;
        // Tab1
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label lblCiudad;
        private System.Windows.Forms.TextBox txtCiudad;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.Label lblEstadoCivil;
        private System.Windows.Forms.ComboBox cmbEstadoCivil;
        private System.Windows.Forms.Label lblSexo;
        private System.Windows.Forms.RadioButton rbHombre;
        private System.Windows.Forms.RadioButton rbMujer;
        private System.Windows.Forms.Panel panelImagen;
        private System.Windows.Forms.Label lblImagenDeco;
        // Tab2
        private System.Windows.Forms.Label lblPregunta1;
        private System.Windows.Forms.RadioButton rbEnfSi;
        private System.Windows.Forms.RadioButton rbEnfNo;
        private System.Windows.Forms.ComboBox cmbEnfermedades;
        private System.Windows.Forms.Label lblPregunta2;
        private System.Windows.Forms.RadioButton rbAlerSi;
        private System.Windows.Forms.RadioButton rbAlerNo;
        private System.Windows.Forms.ComboBox cmbAlergias;
        private System.Windows.Forms.Label lblPregunta3;
        private System.Windows.Forms.RadioButton rbOpSi;
        private System.Windows.Forms.RadioButton rbOpNo;
        private System.Windows.Forms.ComboBox cmbOperaciones;
        private System.Windows.Forms.Label lblPregunta4;
        private System.Windows.Forms.RadioButton rbEjSi;
        private System.Windows.Forms.RadioButton rbEjNo;
        private System.Windows.Forms.ComboBox cmbEjercicio;
        private System.Windows.Forms.Label lblPregunta5;
        private System.Windows.Forms.RadioButton rbDepSi;
        private System.Windows.Forms.RadioButton rbDepNo;
    }
}

