﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (txtContrasena.Text == "1234")
            {
                this.Hide();
                frmMenu menu = new frmMenu();
                menu.Show();
            }
            else
            {
                lblError.Text = "Contraseña incorrecta. Intente de nuevo.";
                txtContrasena.Clear();
                txtContrasena.Focus();
            }
        }
    }
}
