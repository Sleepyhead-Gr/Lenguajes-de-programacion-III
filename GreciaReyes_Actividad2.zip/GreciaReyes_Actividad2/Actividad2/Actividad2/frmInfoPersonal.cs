﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class frmInfoPersonal : Form
    {
        public frmInfoPersonal()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
