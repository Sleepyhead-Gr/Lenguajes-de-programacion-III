﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2
{
    partial class frmOperaciones
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.lblNum4 = new System.Windows.Forms.Label();
            this.txtNum4 = new System.Windows.Forms.TextBox();
            this.lblNum5 = new System.Windows.Forms.Label();
            this.txtNum5 = new System.Windows.Forms.TextBox();
            this.lblNum6 = new System.Windows.Forms.Label();
            this.txtNum6 = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnSuma = new System.Windows.Forms.Button();
            this.btnResta = new System.Windows.Forms.Button();
            this.btnMultiplicacion = new System.Windows.Forms.Button();
            this.btnDivision = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();

            this.panelHeader.SuspendLayout();
            this.SuspendLayout();

            System.Drawing.Font fBold = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            System.Drawing.Font fNormal = new System.Drawing.Font("Segoe UI", 10F);
            System.Drawing.Color azul = System.Drawing.Color.FromArgb(30, 30, 60);

            // ── panelHeader ──
            this.panelHeader.BackColor = azul;
            this.panelHeader.Controls.Add(this.lblTitulo);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(540, 60);

            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Text = "OPERACIONES BÁSICAS";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── lblDescripcion ──
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.lblDescripcion.ForeColor = System.Drawing.Color.Gray;
            this.lblDescripcion.Location = new System.Drawing.Point(20, 68);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(500, 22);
            this.lblDescripcion.Text = "Ingresa 6 números y selecciona la operación a realizar.";
            this.lblDescripcion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── Campos numéricos ──
            int x1 = 50, x2 = 240, w = 130, yS = 100, gap = 42;

            // Num 1
            this.lblNum1.AutoSize = true; this.lblNum1.Font = fBold; this.lblNum1.ForeColor = azul;
            this.lblNum1.Location = new System.Drawing.Point(x1, yS + 5); this.lblNum1.Text = "Número 1:";
            this.txtNum1.Font = fNormal; this.txtNum1.Size = new System.Drawing.Size(w, 27);
            this.txtNum1.Location = new System.Drawing.Point(x2, yS); this.txtNum1.TabIndex = 1;

            // Num 2
            this.lblNum2.AutoSize = true; this.lblNum2.Font = fBold; this.lblNum2.ForeColor = azul;
            this.lblNum2.Location = new System.Drawing.Point(x1, yS + gap + 5); this.lblNum2.Text = "Número 2:";
            this.txtNum2.Font = fNormal; this.txtNum2.Size = new System.Drawing.Size(w, 27);
            this.txtNum2.Location = new System.Drawing.Point(x2, yS + gap); this.txtNum2.TabIndex = 2;

            // Num 3
            this.lblNum3.AutoSize = true; this.lblNum3.Font = fBold; this.lblNum3.ForeColor = azul;
            this.lblNum3.Location = new System.Drawing.Point(x1, yS + gap * 2 + 5); this.lblNum3.Text = "Número 3:";
            this.txtNum3.Font = fNormal; this.txtNum3.Size = new System.Drawing.Size(w, 27);
            this.txtNum3.Location = new System.Drawing.Point(x2, yS + gap * 2); this.txtNum3.TabIndex = 3;

            // Num 4
            this.lblNum4.AutoSize = true; this.lblNum4.Font = fBold; this.lblNum4.ForeColor = azul;
            this.lblNum4.Location = new System.Drawing.Point(x1, yS + gap * 3 + 5); this.lblNum4.Text = "Número 4:";
            this.txtNum4.Font = fNormal; this.txtNum4.Size = new System.Drawing.Size(w, 27);
            this.txtNum4.Location = new System.Drawing.Point(x2, yS + gap * 3); this.txtNum4.TabIndex = 4;

            // Num 5
            this.lblNum5.AutoSize = true; this.lblNum5.Font = fBold; this.lblNum5.ForeColor = azul;
            this.lblNum5.Location = new System.Drawing.Point(x1, yS + gap * 4 + 5); this.lblNum5.Text = "Número 5:";
            this.txtNum5.Font = fNormal; this.txtNum5.Size = new System.Drawing.Size(w, 27);
            this.txtNum5.Location = new System.Drawing.Point(x2, yS + gap * 4); this.txtNum5.TabIndex = 5;

            // Num 6
            this.lblNum6.AutoSize = true; this.lblNum6.Font = fBold; this.lblNum6.ForeColor = azul;
            this.lblNum6.Location = new System.Drawing.Point(x1, yS + gap * 5 + 5); this.lblNum6.Text = "Número 6:";
            this.txtNum6.Font = fNormal; this.txtNum6.Size = new System.Drawing.Size(w, 27);
            this.txtNum6.Location = new System.Drawing.Point(x2, yS + gap * 5); this.txtNum6.TabIndex = 6;

            // ── Resultado ──
            int yRes = yS + gap * 6 + 12;
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblResultado.ForeColor = System.Drawing.Color.FromArgb(0, 150, 136);
            this.lblResultado.Location = new System.Drawing.Point(x1, yRes + 5); this.lblResultado.Text = "Resultado:";
            this.txtResultado.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.txtResultado.BackColor = System.Drawing.Color.FromArgb(240, 255, 250);
            this.txtResultado.ForeColor = System.Drawing.Color.FromArgb(0, 100, 80);
            this.txtResultado.ReadOnly = true;
            this.txtResultado.Size = new System.Drawing.Size(w + 30, 30);
            this.txtResultado.Location = new System.Drawing.Point(x2, yRes); this.txtResultado.TabIndex = 7;

            // ── Botones ──
            int yBtn = yRes + 52;

            this.btnSuma.BackColor = System.Drawing.Color.FromArgb(25, 118, 210);
            this.btnSuma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuma.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnSuma.ForeColor = System.Drawing.Color.White;
            this.btnSuma.Location = new System.Drawing.Point(30, yBtn);
            this.btnSuma.Name = "btnSuma"; this.btnSuma.Size = new System.Drawing.Size(143, 38); this.btnSuma.TabIndex = 8;
            this.btnSuma.Text = "Suma"; this.btnSuma.UseVisualStyleBackColor = false;
            this.btnSuma.Click += new System.EventHandler(this.btnSuma_Click);

            this.btnResta.BackColor = System.Drawing.Color.FromArgb(56, 142, 60);
            this.btnResta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResta.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnResta.ForeColor = System.Drawing.Color.White;
            this.btnResta.Location = new System.Drawing.Point(190, yBtn);
            this.btnResta.Name = "btnResta"; this.btnResta.Size = new System.Drawing.Size(143, 38); this.btnResta.TabIndex = 9;
            this.btnResta.Text = "Resta"; this.btnResta.UseVisualStyleBackColor = false;
            this.btnResta.Click += new System.EventHandler(this.btnResta_Click);

            this.btnMultiplicacion.BackColor = System.Drawing.Color.FromArgb(123, 31, 162);
            this.btnMultiplicacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMultiplicacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnMultiplicacion.ForeColor = System.Drawing.Color.White;
            this.btnMultiplicacion.Location = new System.Drawing.Point(350, yBtn);
            this.btnMultiplicacion.Name = "btnMultiplicacion"; this.btnMultiplicacion.Size = new System.Drawing.Size(143, 38); this.btnMultiplicacion.TabIndex = 10;
            this.btnMultiplicacion.Text = "Multiplicación"; this.btnMultiplicacion.UseVisualStyleBackColor = false;
            this.btnMultiplicacion.Click += new System.EventHandler(this.btnMultiplicacion_Click);

            this.btnDivision.BackColor = System.Drawing.Color.FromArgb(230, 81, 0);
            this.btnDivision.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDivision.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnDivision.ForeColor = System.Drawing.Color.White;
            this.btnDivision.Location = new System.Drawing.Point(30, yBtn + 48);
            this.btnDivision.Name = "btnDivision"; this.btnDivision.Size = new System.Drawing.Size(143, 38); this.btnDivision.TabIndex = 11;
            this.btnDivision.Text = "División"; this.btnDivision.UseVisualStyleBackColor = false;
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);

            this.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(96, 125, 139);
            this.btnLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpiar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnLimpiar.ForeColor = System.Drawing.Color.White;
            this.btnLimpiar.Location = new System.Drawing.Point(190, yBtn + 48);
            this.btnLimpiar.Name = "btnLimpiar"; this.btnLimpiar.Size = new System.Drawing.Size(143, 38); this.btnLimpiar.TabIndex = 12;
            this.btnLimpiar.Text = "Limpiar"; this.btnLimpiar.UseVisualStyleBackColor = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);

            this.btnRegresar.BackColor = System.Drawing.Color.FromArgb(183, 28, 28);
            this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(350, yBtn + 48);
            this.btnRegresar.Name = "btnRegresar"; this.btnRegresar.Size = new System.Drawing.Size(143, 38); this.btnRegresar.TabIndex = 13;
            this.btnRegresar.Text = "Regresar"; this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);

            // ── frmOperaciones ──
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(540, yBtn + 110);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.lblNum1); this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum2); this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum3); this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.lblNum4); this.Controls.Add(this.txtNum4);
            this.Controls.Add(this.lblNum5); this.Controls.Add(this.txtNum5);
            this.Controls.Add(this.lblNum6); this.Controls.Add(this.txtNum6);
            this.Controls.Add(this.lblResultado); this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.btnSuma); this.Controls.Add(this.btnResta);
            this.Controls.Add(this.btnMultiplicacion); this.Controls.Add(this.btnDivision);
            this.Controls.Add(this.btnLimpiar); this.Controls.Add(this.btnRegresar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmOperaciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Operaciones Básicas";

            this.panelHeader.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblNum1, lblNum2, lblNum3, lblNum4, lblNum5, lblNum6;
        private System.Windows.Forms.TextBox txtNum1, txtNum2, txtNum3, txtNum4, txtNum5, txtNum6;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnSuma;
        private System.Windows.Forms.Button btnResta;
        private System.Windows.Forms.Button btnMultiplicacion;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnRegresar;
    }
}
