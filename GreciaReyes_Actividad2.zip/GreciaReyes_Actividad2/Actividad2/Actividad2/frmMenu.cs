﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void mnuSaludo_Click(object sender, EventArgs e)
        {
            frmSaludo f = new frmSaludo();
            f.ShowDialog();
        }

        private void mnuDatosPersonales_Click(object sender, EventArgs e)
        {
            frmInfoPersonal f = new frmInfoPersonal();
            f.ShowDialog();
        }

        private void mnuOperaciones_Click(object sender, EventArgs e)
        {
            frmOperaciones f = new frmOperaciones();
            f.ShowDialog();
        }

        private void mnuSalir_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("¿Deseas salir de la aplicación?", "Salir",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
                Application.Exit();
        }
    }
}