﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class frmOperaciones : Form
    {
        public frmOperaciones()
        {
            InitializeComponent();
        }

        private void btnSuma_Click(object sender, EventArgs e) => Calcular("Suma");
        private void btnResta_Click(object sender, EventArgs e) => Calcular("Resta");
        private void btnMultiplicacion_Click(object sender, EventArgs e) => Calcular("Multiplicación");
        private void btnDivision_Click(object sender, EventArgs e) => Calcular("División");

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear(); txtNum2.Clear(); txtNum3.Clear();
            txtNum4.Clear(); txtNum5.Clear(); txtNum6.Clear();
            txtResultado.Clear();
        }

        private void btnRegresar_Click(object sender, EventArgs e) => this.Close();

        private void Calcular(string operacion)
        {
            TextBox[] campos = { txtNum1, txtNum2, txtNum3, txtNum4, txtNum5, txtNum6 };
            double[] nums = new double[6];

            for (int i = 0; i < 6; i++)
            {
                if (!double.TryParse(campos[i].Text, out nums[i]))
                {
                    MessageBox.Show($"El campo 'Número {i + 1}' no es válido.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            double resultado = 0;
            try
            {
                switch (operacion)
                {
                    case "Suma":
                        foreach (var n in nums) resultado += n;
                        break;
                    case "Resta":
                        resultado = nums[0];
                        for (int i = 1; i < nums.Length; i++) resultado -= nums[i];
                        break;
                    case "Multiplicación":
                        resultado = 1;
                        foreach (var n in nums) resultado *= n;
                        break;
                    case "División":
                        resultado = nums[0];
                        for (int i = 1; i < nums.Length; i++)
                        {
                            if (nums[i] == 0)
                            {
                                MessageBox.Show("No se puede dividir entre cero.", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            resultado /= nums[i];
                        }
                        break;
                }
                txtResultado.Text = Math.Round(resultado, 4).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
