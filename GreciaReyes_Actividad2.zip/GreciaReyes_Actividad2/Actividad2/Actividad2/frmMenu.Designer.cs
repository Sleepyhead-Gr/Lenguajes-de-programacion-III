﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2
{
    partial class frmMenu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuPrincipal = new System.Windows.Forms.MenuStrip();
            this.mnuSaludo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDatosPersonales = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOperaciones = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.panelLateral = new System.Windows.Forms.Panel();
            this.lblOpcionesMenu = new System.Windows.Forms.Label();
            this.lblOp1 = new System.Windows.Forms.Label();
            this.lblOp2 = new System.Windows.Forms.Label();
            this.lblOp3 = new System.Windows.Forms.Label();
            this.lblOp4 = new System.Windows.Forms.Label();
            this.panelContenido = new System.Windows.Forms.Panel();
            this.lblBienvenida = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.lblLinea = new System.Windows.Forms.Label();
            this.lblFooter = new System.Windows.Forms.Label();

            this.menuPrincipal.SuspendLayout();
            this.panelLateral.SuspendLayout();
            this.panelContenido.SuspendLayout();
            this.SuspendLayout();

            // ── menuPrincipal ──
            this.menuPrincipal.BackColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.menuPrincipal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.menuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuSaludo, this.mnuDatosPersonales,
                this.mnuOperaciones, this.mnuSalir });
            this.menuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.menuPrincipal.Name = "menuPrincipal";
            this.menuPrincipal.Size = new System.Drawing.Size(750, 27);
            this.menuPrincipal.TabIndex = 0;

            // mnuSaludo
            this.mnuSaludo.ForeColor = System.Drawing.Color.White;
            this.mnuSaludo.Name = "mnuSaludo";
            this.mnuSaludo.Text = "Saludo";
            this.mnuSaludo.Click += new System.EventHandler(this.mnuSaludo_Click);

            // mnuDatosPersonales
            this.mnuDatosPersonales.ForeColor = System.Drawing.Color.White;
            this.mnuDatosPersonales.Name = "mnuDatosPersonales";
            this.mnuDatosPersonales.Text = "Datos Personales";
            this.mnuDatosPersonales.Click += new System.EventHandler(this.mnuDatosPersonales_Click);

            // mnuOperaciones
            this.mnuOperaciones.ForeColor = System.Drawing.Color.White;
            this.mnuOperaciones.Name = "mnuOperaciones";
            this.mnuOperaciones.Text = "Operaciones Básicas";
            this.mnuOperaciones.Click += new System.EventHandler(this.mnuOperaciones_Click);

            // mnuSalir
            this.mnuSalir.ForeColor = System.Drawing.Color.OrangeRed;
            this.mnuSalir.Name = "mnuSalir";
            this.mnuSalir.Text = "Salir";
            this.mnuSalir.Click += new System.EventHandler(this.mnuSalir_Click);

            // ── panelLateral ──
            this.panelLateral.BackColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.panelLateral.Controls.Add(this.lblOpcionesMenu);
            this.panelLateral.Controls.Add(this.lblOp1);
            this.panelLateral.Controls.Add(this.lblOp2);
            this.panelLateral.Controls.Add(this.lblOp3);
            this.panelLateral.Controls.Add(this.lblOp4);
            this.panelLateral.Location = new System.Drawing.Point(0, 27);
            this.panelLateral.Name = "panelLateral";
            this.panelLateral.Size = new System.Drawing.Size(185, 463);
            this.panelLateral.TabIndex = 1;

            // lblOpcionesMenu
            this.lblOpcionesMenu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblOpcionesMenu.ForeColor = System.Drawing.Color.LightCyan;
            this.lblOpcionesMenu.Location = new System.Drawing.Point(5, 15);
            this.lblOpcionesMenu.Name = "lblOpcionesMenu";
            this.lblOpcionesMenu.Size = new System.Drawing.Size(175, 30);
            this.lblOpcionesMenu.Text = "MENÚ PRINCIPAL";
            this.lblOpcionesMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblOp1
            this.lblOp1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblOp1.ForeColor = System.Drawing.Color.White;
            this.lblOp1.Location = new System.Drawing.Point(10, 65);
            this.lblOp1.Name = "lblOp1";
            this.lblOp1.Size = new System.Drawing.Size(165, 25);
            this.lblOp1.Text = "► Saludo";

            // lblOp2
            this.lblOp2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblOp2.ForeColor = System.Drawing.Color.White;
            this.lblOp2.Location = new System.Drawing.Point(10, 100);
            this.lblOp2.Name = "lblOp2";
            this.lblOp2.Size = new System.Drawing.Size(165, 25);
            this.lblOp2.Text = "► Datos Personales";

            // lblOp3
            this.lblOp3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblOp3.ForeColor = System.Drawing.Color.White;
            this.lblOp3.Location = new System.Drawing.Point(10, 135);
            this.lblOp3.Name = "lblOp3";
            this.lblOp3.Size = new System.Drawing.Size(165, 25);
            this.lblOp3.Text = "► Operaciones Básicas";

            // lblOp4
            this.lblOp4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblOp4.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblOp4.Location = new System.Drawing.Point(10, 170);
            this.lblOp4.Name = "lblOp4";
            this.lblOp4.Size = new System.Drawing.Size(165, 25);
            this.lblOp4.Text = "► Salir";

            // ── panelContenido ──
            this.panelContenido.BackColor = System.Drawing.Color.White;
            this.panelContenido.Controls.Add(this.lblBienvenida);
            this.panelContenido.Controls.Add(this.lblLinea);
            this.panelContenido.Controls.Add(this.lblSubtitulo);
            this.panelContenido.Controls.Add(this.lblFooter);
            this.panelContenido.Location = new System.Drawing.Point(185, 27);
            this.panelContenido.Name = "panelContenido";
            this.panelContenido.Size = new System.Drawing.Size(563, 463);
            this.panelContenido.TabIndex = 2;

            // lblBienvenida
            this.lblBienvenida.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblBienvenida.ForeColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.lblBienvenida.Location = new System.Drawing.Point(10, 80);
            this.lblBienvenida.Name = "lblBienvenida";
            this.lblBienvenida.Size = new System.Drawing.Size(543, 50);
            this.lblBienvenida.Text = "¡Bienvenido al Sistema!";
            this.lblBienvenida.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblLinea
            this.lblLinea.BackColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.lblLinea.Location = new System.Drawing.Point(120, 138);
            this.lblLinea.Name = "lblLinea";
            this.lblLinea.Size = new System.Drawing.Size(300, 3);

            // lblSubtitulo
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblSubtitulo.ForeColor = System.Drawing.Color.Gray;
            this.lblSubtitulo.Location = new System.Drawing.Point(10, 150);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.Size = new System.Drawing.Size(543, 60);
            this.lblSubtitulo.Text = "Selecciona una opción del menú superior\npara comenzar a usar la aplicación.";
            this.lblSubtitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblFooter
            this.lblFooter.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.lblFooter.ForeColor = System.Drawing.Color.LightGray;
            this.lblFooter.Location = new System.Drawing.Point(10, 420);
            this.lblFooter.Name = "lblFooter";
            this.lblFooter.Size = new System.Drawing.Size(543, 25);
            this.lblFooter.Text = "Lenguajes de Programación III  •  C#  •  Windows Forms";
            this.lblFooter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── frmMenu ──
            this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.ClientSize = new System.Drawing.Size(750, 490);
            this.Controls.Add(this.panelContenido);
            this.Controls.Add(this.panelLateral);
            this.Controls.Add(this.menuPrincipal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuPrincipal;
            this.MaximizeBox = false;
            this.Name = "frmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menú";
            this.FormClosed += (s, e) => System.Windows.Forms.Application.Exit();

            this.menuPrincipal.ResumeLayout(false);
            this.menuPrincipal.PerformLayout();
            this.panelLateral.ResumeLayout(false);
            this.panelContenido.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.MenuStrip menuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem mnuSaludo;
        private System.Windows.Forms.ToolStripMenuItem mnuDatosPersonales;
        private System.Windows.Forms.ToolStripMenuItem mnuOperaciones;
        private System.Windows.Forms.ToolStripMenuItem mnuSalir;
        private System.Windows.Forms.Panel panelLateral;
        private System.Windows.Forms.Label lblOpcionesMenu;
        private System.Windows.Forms.Label lblOp1;
        private System.Windows.Forms.Label lblOp2;
        private System.Windows.Forms.Label lblOp3;
        private System.Windows.Forms.Label lblOp4;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.Label lblBienvenida;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Label lblLinea;
        private System.Windows.Forms.Label lblFooter;
        private object resources;
    }
}
